scoreboard players add @s adco.score 5
