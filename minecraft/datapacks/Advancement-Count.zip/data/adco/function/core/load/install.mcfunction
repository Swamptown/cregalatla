scoreboard players set %installed adco.data 1
scoreboard objectives add 2mal3.debug_mode dummy
scoreboard objectives add adco.score dummy
scoreboard objectives setdisplay list adco.score
scoreboard objectives modify adco.score rendertype integer
scoreboard objectives add adco.recalculate_version dummy
scoreboard players set $version adco.data 20000
schedule function adco:core/load/install/send_message 4s replace
