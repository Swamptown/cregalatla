tellraw @a {"text": "Installed Advancement Count v2.0.0 from 2mal3!", "color": "green"}
