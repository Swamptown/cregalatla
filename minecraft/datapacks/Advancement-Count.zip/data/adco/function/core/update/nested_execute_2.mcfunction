scoreboard players set $version adco.data 10103
tellraw @a[scores={2mal3.debug_mode=3..}] ["", {"text": "[", "color": "gray"}, {"text": "ADCO", "color": "green"}, {"text": "/", "color": "gray"}, {"text": "INFO", "color": "green"}, {"text": "/", "color": "gray"}, {"text": "Server", "color": "green"}, {"text": "]: ", "color": "gray"}, {"text": "Updated to 1.1.3", "color": "green"}]
