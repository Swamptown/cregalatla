scoreboard players set $version adco.data 20000
tellraw @a[scores={2mal3.debug_mode=3..}] ["", {"text": "[", "color": "gray"}, {"text": "ADCO", "color": "green"}, {"text": "/", "color": "gray"}, {"text": "INFO", "color": "green"}, {"text": "/", "color": "gray"}, {"text": "Server", "color": "green"}, {"text": "]: ", "color": "gray"}, {"text": "Updated to v2.0.0", "color": "green"}]
scoreboard objectives add adco.recalculate_version dummy
