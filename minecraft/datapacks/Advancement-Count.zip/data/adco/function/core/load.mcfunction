scoreboard objectives add adco.data dummy
tellraw @a[scores={2mal3.debug_mode=3..}] ["", {"text": "[", "color": "gray"}, {"text": "ADCO", "color": "green"}, {"text": "/", "color": "gray"}, {"text": "INFO", "color": "green"}, {"text": "/", "color": "gray"}, {"text": "Server", "color": "green"}, {"text": "]: ", "color": "gray"}, {"text": "Loaded!", "color": "green"}]
execute unless score %installed adco.data matches 1 run function adco:core/load/install
execute if score %installed adco.data matches 1 unless score $version adco.data matches 20000 run function adco:core/load/update
scoreboard players add %latest adco.recalculate_version 1
