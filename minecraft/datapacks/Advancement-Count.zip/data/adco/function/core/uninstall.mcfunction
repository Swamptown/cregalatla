scoreboard objectives remove adco.data
scoreboard objectives remove adco.score
scoreboard objectives remove adco.recalculate_version
tellraw @a {"text": "Uninstalled Advancement Count v2.0.0 from 2mal3!", "color": "green"}
datapack disable "file/Advancement-Count"
datapack disable "file/Advancement-Count.zip"
