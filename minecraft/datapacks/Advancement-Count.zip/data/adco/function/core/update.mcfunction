execute if score $version adco.data matches 10100 run function adco:core/update/nested_execute_0
execute if score $version adco.data matches 10101 run function adco:core/update/nested_execute_1
execute if score $version adco.data matches 10102 run function adco:core/update/nested_execute_2
execute if score $version adco.data matches 10103 run function adco:core/update/nested_execute_3
execute if score $version adco.data matches 10104 run function adco:core/update/nested_execute_4
execute if score $version adco.data matches 10200 run function adco:core/update/nested_execute_5
