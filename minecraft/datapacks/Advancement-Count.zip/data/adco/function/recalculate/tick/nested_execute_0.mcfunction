scoreboard players operation @s adco.recalculate_version = %latest adco.recalculate_version
function adco:recalculate/player
