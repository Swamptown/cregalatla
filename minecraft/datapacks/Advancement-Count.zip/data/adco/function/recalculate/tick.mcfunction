schedule function adco:recalculate/tick 1s replace
execute as @a unless score @s adco.recalculate_version = %latest adco.recalculate_version run function adco:recalculate/tick/nested_execute_0
